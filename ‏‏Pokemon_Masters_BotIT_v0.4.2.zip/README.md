# Pokemon Masters Bot-It v0.3

Fully portable come with installer to easy screen the images while bot is running.
no data saved / no data sent
If *.exe give you false anti viruse you can download the *.exe from autohotkey and rename it to the script name it only run the code..

Youtube:

**Co-Op Run**


[![Co-op run](https://i9.ytimg.com/vi/W-u14v51vLI/mq2.jpg?sqp=CJirw-sF&rs=AOn4CLBmvKQj34CzSB0fLOE6vMS4QCF5mQ)](https://youtu.be/W-u14v51vLI "Co-op run - Click to Watch!")


**Installer show**


[![Installer show](https://i9.ytimg.com/vi/BYHvAxWxoWE/mq1.jpg?sqp=CMStw-sF&rs=AOn4CLCpS6QxJAgzWodlg__B70-42cVW3w)](https://youtu.be/BYHvAxWxoWE "Installer show - Click to Watch!")

**Full Core Install**


[![Full Core Installn](https://i9.ytimg.com/vi/eImujvM4V3Q/mq2.jpg?sqp=CJirw-sF&rs=AOn4CLC9MpJDm7zjXs6fM7S6dAXgs1nG_w)](https://youtu.be/eImujvM4V3Q "Full Core Install - Click to Watch!")




Hotkey:

esc - cancel pic crop

F2  - target bot it 

F8 - Kill all bot

PC
Androind / Mirror
https://github.com/DizzyduckAR/AutoMirror
for 1 click free mirror android

Bot-it games and help can be found in discord
https://discord.gg/CUgnVpk


