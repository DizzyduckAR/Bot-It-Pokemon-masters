# Pokemon Masters Bot-It v0.4.75

For anyone who wanna move to 0.4.75 with old img dir.
YOU MUST Run Bot-it Image Rename.bat Once.
It will conver ya to the new Botit format alone

We prep for Background Windows Scan with GrayScale ON


Fully portable come with installer to easy screen the images while bot is running.
no data saved / no data sent
If *.exe give you false anti viruse you can download the *.exe from autohotkey and rename it to the script name it only run the code..

Log:

* Image click on canter
* Remove offset from X no issue with low res anymore
* Find Click connected and active on all calls
* Global is back!! Option / Option 2 (o75 default can be move to o95 in both) 
* Full baseline for image found tracking (need over night testing)



Pokemon masters V0.45

*Bot it Use Postmassage to command the target mirror (no more mouse use)




Pokemon masters V0.43

*mouse blink return mouse to start pos

*random ad killer with 9 autograb images from dir img/rndm/ (anything you screen!!)

*fail safe added for user getting apk crash bot will reload the app for ya

*image tracking disable atm did not work as hoped (ai will keep testing it)

*bot logic is improved

*bot let you pick and change any event by simple pic take and it on..

*co-op supported

*controller delay. might be moving to adb event sooner then expected

Youtube:

**Co-Op Run**


[![Co-op run](https://i9.ytimg.com/vi/W-u14v51vLI/mq2.jpg?sqp=CJirw-sF&rs=AOn4CLBmvKQj34CzSB0fLOE6vMS4QCF5mQ)](https://youtu.be/W-u14v51vLI "Co-op run - Click to Watch!")


**Installer show**


[![Installer show](https://i9.ytimg.com/vi/BYHvAxWxoWE/mq1.jpg?sqp=CMStw-sF&rs=AOn4CLCpS6QxJAgzWodlg__B70-42cVW3w)](https://youtu.be/BYHvAxWxoWE "Installer show - Click to Watch!")

**Full Core Install**


[![Full Core Installn](https://i9.ytimg.com/vi/eImujvM4V3Q/mq2.jpg?sqp=CJirw-sF&rs=AOn4CLC9MpJDm7zjXs6fM7S6dAXgs1nG_w)](https://youtu.be/eImujvM4V3Q "Full Core Install - Click to Watch!")




Hotkey:

esc - cancel pic crop

F2  - target bot it 

F8 - Kill all bot

PC
Androind / Mirror
https://github.com/DizzyduckAR/AutoMirror
for 1 click free mirror android

Bot-it games and help can be found in discord
https://discord.gg/CUgnVpk


